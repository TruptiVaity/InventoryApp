package com.example.inventoryapp;

class EditorActivity {
}
